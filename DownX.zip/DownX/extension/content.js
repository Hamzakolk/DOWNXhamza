// Adds a small "Download with DownX" button over each video on the page.
// Runs only in the top frame. The button sends the page URL to the background script.
(() => {
  if (window.top !== window) return;

  const api = typeof browser !== "undefined" ? browser : chrome;
  const MIN_WIDTH = 200;
  const MIN_HEIGHT = 120;
  // video element -> { host, button, hideTimer }
  const entries = new Map();
  let scheduled = false;

  function makeButton(video) {
    const host = document.createElement("div");
    host.style.cssText =
      "position:fixed;z-index:2147483647;display:none;margin:0;padding:0;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        button {
          all: initial;
          font: 600 12px/1 system-ui, sans-serif;
          padding: 7px 10px;
          border-radius: 8px;
          background: #E0A84F;
          color: #1a1a1a;
          box-shadow: 0 2px 8px rgba(0,0,0,.35);
          cursor: pointer;
          pointer-events: auto;
          white-space: nowrap;
        }
        button:hover { background: #C98F3A; }
      </style>
      <button type="button">Download with DownX</button>
    `;
    const button = root.querySelector("button");

    const entry = { host, button, hideTimer: null };

    const show = () => {
      clearTimeout(entry.hideTimer);
      host.style.display = "block";
    };
    const hideSoon = () => {
      entry.hideTimer = setTimeout(() => {
        if (!video.matches(":hover")) host.style.display = "none";
      }, 250);
    };

    video.addEventListener("mouseenter", show);
    video.addEventListener("mouseleave", hideSoon);
    button.addEventListener("mouseenter", show);
    button.addEventListener("mouseleave", hideSoon);

    button.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      button.textContent = "Sending...";
      api.runtime.sendMessage({ type: "send", url: location.href }, (res) => {
        if (res && res.ok) {
          button.textContent = "Added to DownX";
        } else {
          button.textContent = (res && res.error) || "Could not send";
        }
        setTimeout(() => (button.textContent = "Download with DownX"), 2500);
      });
    });

    document.documentElement.appendChild(host);
    return entry;
  }

  function attach(video) {
    if (entries.has(video)) return;
    entries.set(video, makeButton(video));
    schedule();
  }

  function reposition() {
    scheduled = false;
    for (const [video, entry] of entries) {
      if (!video.isConnected) {
        entry.host.remove();
        entries.delete(video);
        continue;
      }
      const r = video.getBoundingClientRect();
      const visible =
        r.width >= MIN_WIDTH &&
        r.height >= MIN_HEIGHT &&
        r.bottom > 0 &&
        r.top < window.innerHeight;
      if (!visible) {
        entry.host.style.display = "none";
        continue;
      }
      // Keep the button inside the video, at the top-right corner.
      const left = Math.max(8, Math.min(r.right - 170, window.innerWidth - 170));
      const top = Math.max(8, r.top + 8);
      entry.host.style.left = `${left}px`;
      entry.host.style.top = `${top}px`;
    }
  }

  function schedule() {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(reposition);
    }
  }

  function scan(root) {
    if (root.nodeType !== Node.ELEMENT_NODE) return;
    if (root.tagName === "VIDEO") attach(root);
    root.querySelectorAll?.("video").forEach(attach);
  }

  scan(document.documentElement);

  new MutationObserver((mutations) => {
    for (const m of mutations) {
      m.addedNodes.forEach(scan);
    }
  }).observe(document.documentElement, { childList: true, subtree: true });

  window.addEventListener("scroll", schedule, { capture: true, passive: true });
  window.addEventListener("resize", schedule, { passive: true });
  setInterval(schedule, 500); // catches layout changes the events miss
})();
