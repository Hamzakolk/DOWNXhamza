import os
import sys
import json
import queue
import shutil
import secrets
import threading
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import customtkinter as ctk
import yt_dlp
from tkinter import filedialog

APP_NAME = "DownX"
ACCENT = "#E0A84F"
ACCENT_HOVER = "#C98F3A"
ERROR = "#E07A5F"
QUALITY_KEYS = ["best", "1080", "720", "480", "audio"]
FINISHED = ("done", "failed", "cancelled")
SETTINGS_DIR = os.path.join(os.path.expanduser("~"), ".downx")
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "settings.json")
BRIDGE_PORT = 47823

DEFAULT_SETTINGS = {
    "lang": "en",
    "save_dir": os.path.join(os.path.expanduser("~"), "Downloads"),
    "max_concurrent": 3,
    "default_quality": "best",
    "bridge_token": "",
    "bridge_port": BRIDGE_PORT,
}

TEXT = {
    "en": {
        "subtitle": "Video & audio downloader",
        "placeholder": "Paste a video or playlist link",
        "add": "Add",
        "quality": "Quality",
        "playlist": "Full playlist",
        "folder": "Save to",
        "change": "Change",
        "clear": "Clear finished",
        "cancel": "Cancel",
        "open": "Open folder",
        "queued": "Queued",
        "downloading": "Downloading",
        "processing": "Processing",
        "done": "Completed",
        "failed": "Failed",
        "cancelled": "Cancelled",
        "invalid": "Paste a valid link starting with http:// or https://",
        "no_ffmpeg": "ffmpeg not found. Merging and MP3 need it (put it in PATH or next to DownX).",
        "lang_btn": "العربية",
        "settings": "Settings",
        "settings_title": "Settings",
        "max_concurrent": "Simultaneous downloads",
        "default_quality": "Default quality",
        "save": "Save",
        "settings_note": "Simultaneous downloads apply to new downloads.",
        "bridge": "Browser extension token",
        "bridge_hint": "Paste this token in the browser extension options to connect.",
        "bridge_error": "Browser bridge could not start. The port may be in use.",
        "bridge_ok": "Browser bridge is active",
        "q": {
            "best": "Best available",
            "1080": "1080p",
            "720": "720p",
            "480": "480p",
            "audio": "Audio only (MP3)",
        },
    },
    "ar": {
        "subtitle": "تحميل الفيديو والصوت",
        "placeholder": "الصق رابط فيديو أو قائمة تشغيل",
        "add": "إضافة",
        "quality": "الجودة",
        "playlist": "قائمة التشغيل كاملة",
        "folder": "الحفظ في",
        "change": "تغيير",
        "clear": "مسح المكتمل",
        "cancel": "إلغاء",
        "open": "فتح المجلد",
        "queued": "في الانتظار",
        "downloading": "جاري التحميل",
        "processing": "جاري المعالجة",
        "done": "اكتمل",
        "failed": "فشل",
        "cancelled": "أُلغي",
        "invalid": "الصق رابطًا صحيحًا يبدأ بـ http:// أو https://",
        "no_ffmpeg": "ffmpeg غير موجود. الدمج وتحويل MP3 يحتاجانه (ضعه في PATH أو بجوار DownX).",
        "lang_btn": "English",
        "settings": "الإعدادات",
        "settings_title": "الإعدادات",
        "max_concurrent": "عدد التحميلات المتزامنة",
        "default_quality": "الجودة الافتراضية",
        "save": "حفظ",
        "settings_note": "التحميلات المتزامنة تطبق على التحميلات الجديدة.",
        "bridge": "توكن إضافة المتصفح",
        "bridge_hint": "الصق هذا التوكن في إعدادات الإضافة في المتصفح للربط.",
        "bridge_error": "تعذّر تشغيل ربط المتصفح. ربما المنفذ مستخدم.",
        "bridge_ok": "ربط المتصفح يعمل",
        "q": {
            "best": "أفضل جودة متاحة",
            "1080": "1080p",
            "720": "720p",
            "480": "480p",
            "audio": "صوت فقط (MP3)",
        },
    },
}


def load_settings():
    settings = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            settings.update(json.load(f))
    except (OSError, ValueError):
        pass
    if not os.path.isdir(settings["save_dir"]):
        settings["save_dir"] = DEFAULT_SETTINGS["save_dir"]
    settings["max_concurrent"] = min(max(int(settings["max_concurrent"]), 1), 5)
    if not settings["bridge_token"]:
        settings["bridge_token"] = secrets.token_urlsafe(24)
        save_settings(settings)
    return settings


def save_settings(settings):
    os.makedirs(SETTINGS_DIR, exist_ok=True)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)


def find_ffmpeg_dir():
    """Return a directory containing ffmpeg, or None.
    Checks PATH first, then next to the app (works for a PyInstaller build too)."""
    if shutil.which("ffmpeg"):
        return None  # yt-dlp will find it on PATH
    candidates = [os.path.dirname(os.path.abspath(sys.argv[0])),
                  getattr(sys, "_MEIPASS", ""),
                  os.path.dirname(sys.executable)]
    for d in candidates:
        if d and os.path.isfile(os.path.join(d, "ffmpeg.exe" if os.name == "nt" else "ffmpeg")):
            return d
    return "missing"


class BridgeHandler(BaseHTTPRequestHandler):
    """Local HTTP endpoint used by the browser extension. Listens on 127.0.0.1 only."""

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-DownX-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def _reply(self, code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self.path == "/ping":
            self._reply(200, {"app": APP_NAME})
        else:
            self._reply(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/add":
            self._reply(404, {"error": "not found"})
            return
        if self.headers.get("X-DownX-Token", "") != self.server.token:
            self._reply(403, {"error": "bad token"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            data = json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            self._reply(400, {"error": "bad json"})
            return
        url = str(data.get("url", "")).strip()
        if not url.startswith(("http://", "https://")):
            self._reply(400, {"error": "invalid url"})
            return
        self.server.inbox.put(url)
        self._reply(200, {"ok": True})

    def log_message(self, format, *args):
        pass


def start_bridge(token, port, inbox):
    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), BridgeHandler)
    except OSError:
        return None
    server.token = token
    server.inbox = inbox
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


class UserCancelled(Exception):
    pass


class Item:
    def __init__(self, url, folder):
        self.url = url
        self.folder = folder
        self.opts = None
        self.title = url
        self.status = "queued"
        self.progress = 0.0
        self.speed = None
        self.cancelled = False
        self.row = None


def fmt_speed(bps):
    if not bps:
        return ""
    if bps >= 1024 * 1024:
        return f"{bps / 1024 / 1024:.2f} MB/s"
    return f"{bps / 1024:.0f} KB/s"


class SettingsWindow(ctk.CTkToplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title(app.t("settings_title"))
        self.geometry("500x440")
        self.resizable(False, False)
        self.grid_columnconfigure(1, weight=1)

        self.folder_lbl = ctk.CTkLabel(self, text=app.save_dir, anchor="w", text_color="gray60")
        self.concurrent_lbl = ctk.CTkLabel(self, text="")
        self.quality_lbl = ctk.CTkLabel(self, text="")
        self.note_lbl = ctk.CTkLabel(self, text="", text_color="gray60", wraplength=440)
        self.folder_title = ctk.CTkLabel(self, text=app.t("folder"))
        self.folder_title.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 8))
        self.folder_lbl.grid(row=0, column=1, sticky="ew", padx=(0, 8), pady=(20, 8))
        self.change_btn = ctk.CTkButton(self, text=app.t("change"), width=90,
                                        fg_color="transparent", border_width=1,
                                        command=self._pick_folder)
        self.change_btn.grid(row=0, column=2, padx=(0, 20), pady=(20, 8))

        self.concurrent_lbl.configure(text=app.t("max_concurrent"))
        self.concurrent_lbl.grid(row=1, column=0, sticky="w", padx=20, pady=8)
        self.concurrent_menu = ctk.CTkOptionMenu(self, width=120,
                                                 values=[str(i) for i in range(1, 6)])
        self.concurrent_menu.set(str(app.max_concurrent))
        self.concurrent_menu.grid(row=1, column=1, sticky="w", padx=0, pady=8)

        self.quality_lbl.configure(text=app.t("default_quality"))
        self.quality_lbl.grid(row=2, column=0, sticky="w", padx=20, pady=8)
        labels = [TEXT[app.lang]["q"][k] for k in QUALITY_KEYS]
        self.quality_menu = ctk.CTkOptionMenu(self, width=200, values=labels)
        self.quality_menu.set(TEXT[app.lang]["q"][app.default_quality])
        self.quality_menu.grid(row=2, column=1, sticky="w", padx=0, pady=8)

        self.note_lbl.configure(text=app.t("settings_note"))
        self.note_lbl.grid(row=3, column=0, columnspan=3, sticky="w", padx=20, pady=(12, 8))

        self.bridge_lbl = ctk.CTkLabel(self, text=app.t("bridge"))
        self.bridge_lbl.grid(row=4, column=0, sticky="w", padx=20, pady=8)
        self.token_entry = ctk.CTkEntry(self, width=260)
        self.token_entry.insert(0, app.bridge_token)
        self.token_entry.configure(state="readonly")
        self.token_entry.grid(row=4, column=1, columnspan=2, sticky="w", padx=(0, 20), pady=8)
        self.bridge_hint = ctk.CTkLabel(self, text=app.t("bridge_hint"), text_color="gray60",
                                        wraplength=440, anchor="w", justify="left")
        self.bridge_hint.grid(row=5, column=0, columnspan=3, sticky="w", padx=20, pady=(0, 8))

        self.save_btn = ctk.CTkButton(self, text=app.t("save"), fg_color=ACCENT,
                                      hover_color=ACCENT_HOVER, text_color="#1A1A1A",
                                      command=self._save)
        self.save_btn.grid(row=6, column=2, sticky="e", padx=20, pady=(8, 20))

        self.selected_folder = app.save_dir

    def _pick_folder(self):
        chosen = filedialog.askdirectory(initialdir=self.selected_folder, parent=self)
        if chosen:
            self.selected_folder = chosen
            self.folder_lbl.configure(text=chosen)

    def _save(self):
        q_label = self.quality_menu.get()
        qkey = next((k for k in QUALITY_KEYS if TEXT[self.app.lang]["q"][k] == q_label), "best")
        self.app.apply_settings(
            save_dir=self.selected_folder,
            max_concurrent=int(self.concurrent_menu.get()),
            default_quality=qkey,
        )
        self.destroy()


class DownX(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.title(APP_NAME)
        self.geometry("880x640")
        self.minsize(720, 520)

        s = load_settings()
        self.lang = s["lang"]
        self.save_dir = s["save_dir"]
        self.max_concurrent = s["max_concurrent"]
        self.default_quality = s["default_quality"]
        self.quality_key = self.default_quality
        self.slots = threading.BoundedSemaphore(self.max_concurrent)
        self.ffmpeg_dir = find_ffmpeg_dir()
        self.bridge_token = s["bridge_token"]
        self.bridge_port = int(s["bridge_port"])
        self.inbox = queue.Queue()
        self.bridge = start_bridge(self.bridge_token, self.bridge_port, self.inbox)

        self.items = []
        self._build()
        self._apply_lang()
        if self.ffmpeg_dir == "missing":
            self.status_lbl.configure(text=self.t("no_ffmpeg"), text_color=ERROR)
        elif self.bridge is None:
            self.status_lbl.configure(text=self.t("bridge_error"), text_color=ERROR)
        self._poll()

    def t(self, key):
        return TEXT[self.lang][key]

    def _persist(self):
        save_settings({
            "lang": self.lang,
            "save_dir": self.save_dir,
            "max_concurrent": self.max_concurrent,
            "default_quality": self.default_quality,
            "bridge_token": self.bridge_token,
            "bridge_port": self.bridge_port,
        })

    # ---------- UI ----------
    def _build(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=20, pady=(16, 6))
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(header, text=APP_NAME, font=ctk.CTkFont(size=28, weight="bold"),
                     text_color=ACCENT).grid(row=0, column=0, sticky="w")
        self.subtitle = ctk.CTkLabel(header, text="", text_color="gray60")
        self.subtitle.grid(row=1, column=0, sticky="w")

        btns = ctk.CTkFrame(header, fg_color="transparent")
        btns.grid(row=0, column=1, rowspan=2, sticky="e")
        self.settings_btn = ctk.CTkButton(btns, width=90, fg_color="transparent",
                                          border_width=1, command=self._open_settings)
        self.settings_btn.pack(side="left", padx=(0, 8))
        self.lang_btn = ctk.CTkButton(btns, width=90, fg_color="transparent",
                                      border_width=1, command=self._toggle_lang)
        self.lang_btn.pack(side="left")

        bar = ctk.CTkFrame(self, corner_radius=14)
        bar.grid(row=1, column=0, sticky="ew", padx=20, pady=8)
        bar.grid_columnconfigure(0, weight=1)

        self.url_entry = ctk.CTkEntry(bar, height=40)
        self.url_entry.grid(row=0, column=0, sticky="ew", padx=(14, 8), pady=(14, 8))
        self.url_entry.bind("<Return>", lambda e: self._add())
        self.add_btn = ctk.CTkButton(bar, width=110, height=40, fg_color=ACCENT,
                                     hover_color=ACCENT_HOVER, text_color="#1A1A1A",
                                     command=self._add)
        self.add_btn.grid(row=0, column=1, padx=(0, 14), pady=(14, 8))

        opts = ctk.CTkFrame(bar, fg_color="transparent")
        opts.grid(row=1, column=0, columnspan=2, sticky="ew", padx=14, pady=(0, 14))
        opts.grid_columnconfigure(3, weight=1)

        self.quality_lbl = ctk.CTkLabel(opts, text="")
        self.quality_lbl.grid(row=0, column=0, padx=(0, 8))
        self.quality_menu = ctk.CTkOptionMenu(opts, width=180, values=[""],
                                              command=self._on_quality)
        self.quality_menu.grid(row=0, column=1, padx=(0, 16))

        self.playlist_var = ctk.BooleanVar(value=False)
        self.playlist_chk = ctk.CTkCheckBox(opts, text="", variable=self.playlist_var)
        self.playlist_chk.grid(row=0, column=2, padx=(0, 16))

        self.folder_lbl = ctk.CTkLabel(opts, text="", anchor="w", text_color="gray60")
        self.folder_lbl.grid(row=0, column=3, sticky="ew", padx=(0, 8))
        self.change_btn = ctk.CTkButton(opts, width=90, fg_color="transparent",
                                        border_width=1, command=self._change_folder)
        self.change_btn.grid(row=0, column=4)

        self.list_frame = ctk.CTkScrollableFrame(self, corner_radius=14)
        self.list_frame.grid(row=2, column=0, sticky="nsew", padx=20, pady=(0, 8))
        self.list_frame.grid_columnconfigure(0, weight=1)

        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.grid(row=3, column=0, sticky="ew", padx=20, pady=(0, 14))
        footer.grid_columnconfigure(0, weight=1)
        self.status_lbl = ctk.CTkLabel(footer, text="", anchor="w", text_color="gray60")
        self.status_lbl.grid(row=0, column=0, sticky="ew")
        self.clear_btn = ctk.CTkButton(footer, width=150, fg_color="transparent",
                                       border_width=1, command=self._clear_finished)
        self.clear_btn.grid(row=0, column=1)

    def _apply_lang(self):
        ar = self.lang == "ar"
        self.url_entry.configure(placeholder_text=self.t("placeholder"),
                                 justify="right" if ar else "left")
        self.subtitle.configure(text=self.t("subtitle"))
        self.lang_btn.configure(text=self.t("lang_btn"))
        self.settings_btn.configure(text=self.t("settings"))
        self.add_btn.configure(text=self.t("add"))
        self.quality_lbl.configure(text=self.t("quality"))
        labels = [TEXT[self.lang]["q"][k] for k in QUALITY_KEYS]
        self.quality_menu.configure(values=labels)
        self.quality_menu.set(TEXT[self.lang]["q"][self.quality_key])
        self.playlist_chk.configure(text=self.t("playlist"))
        self.change_btn.configure(text=self.t("change"))
        self.clear_btn.configure(text=self.t("clear"))
        self._refresh_folder_label()

    def _refresh_folder_label(self):
        self.folder_lbl.configure(text=f"{self.t('folder')}: {self.save_dir}")

    def _toggle_lang(self):
        self.lang = "ar" if self.lang == "en" else "en"
        self._apply_lang()
        self._persist()

    def _on_quality(self, label):
        for k in QUALITY_KEYS:
            if TEXT[self.lang]["q"][k] == label:
                self.quality_key = k
                break

    def _change_folder(self):
        chosen = filedialog.askdirectory(initialdir=self.save_dir)
        if chosen:
            self.save_dir = chosen
            self._refresh_folder_label()
            self._persist()

    def _open_settings(self):
        SettingsWindow(self)

    def apply_settings(self, save_dir, max_concurrent, default_quality):
        self.save_dir = save_dir
        self.max_concurrent = max_concurrent
        self.default_quality = default_quality
        self.quality_key = default_quality
        # New semaphore: new downloads use the new limit; running ones finish on the old one.
        self.slots = threading.BoundedSemaphore(max_concurrent)
        self._apply_lang()
        self._persist()

    # ---------- Downloads ----------
    def _build_opts(self, folder, quality, playlist, hook):
        opts = {
            "outtmpl": os.path.join(folder, "%(title).150B.%(ext)s"),
            "noplaylist": not playlist,
            "progress_hooks": [hook],
            "quiet": True,
            "no_warnings": True,
            "merge_output_format": "mp4",
        }
        if self.ffmpeg_dir not in (None, "missing"):
            opts["ffmpeg_location"] = self.ffmpeg_dir
        if quality == "audio":
            opts["format"] = "bestaudio/best"
            opts["postprocessors"] = [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }]
        elif quality == "best":
            opts["format"] = "bv*+ba/b"
        else:
            h = int(quality)
            opts["format"] = f"bv*[height<={h}]+ba/b[height<={h}]"
        return opts

    def _add(self):
        url = self.url_entry.get().strip()
        if not url.startswith(("http://", "https://")):
            self.status_lbl.configure(text=self.t("invalid"), text_color=ERROR)
            return
        self._enqueue(url, bool(self.playlist_var.get()))
        self.url_entry.delete(0, "end")

    def _enqueue(self, url, playlist):
        if self.ffmpeg_dir == "missing":
            self.status_lbl.configure(text=self.t("no_ffmpeg"), text_color=ERROR)
        else:
            self.status_lbl.configure(text="", text_color="gray60")

        item = Item(url, self.save_dir)
        item.opts = self._build_opts(self.save_dir, self.quality_key, playlist,
                                     lambda d, it=item: self._hook(it, d))
        self.items.append(item)
        self._make_row(item)
        threading.Thread(target=self._worker, args=(item, self.slots), daemon=True).start()

    def _hook(self, item, d):
        if item.cancelled:
            raise UserCancelled()
        info = d.get("info_dict") or {}
        if info.get("title"):
            item.title = info["title"]
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            if total:
                item.progress = min(d["downloaded_bytes"] / total, 0.99)
            item.speed = d.get("speed")
            item.status = "downloading"
        elif d["status"] == "finished":
            item.status = "processing"

    def _worker(self, item, slots):
        with slots:
            if item.cancelled:
                item.status = "cancelled"
                return
            item.status = "downloading"
            try:
                with yt_dlp.YoutubeDL(item.opts) as ydl:
                    ydl.download([item.url])
                if item.cancelled:
                    item.status = "cancelled"
                else:
                    item.status = "done"
                    item.progress = 1.0
            except UserCancelled:
                item.status = "cancelled"
            except Exception:
                item.status = "cancelled" if item.cancelled else "failed"

    def _cancel(self, item):
        item.cancelled = True
        if item.status == "queued":
            item.status = "cancelled"

    def _open_folder(self, folder):
        if sys.platform.startswith("win"):
            os.startfile(folder)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])
        else:
            subprocess.Popen(["xdg-open", folder])

    def _make_row(self, item):
        frame = ctk.CTkFrame(self.list_frame, corner_radius=12)
        frame.pack(fill="x", padx=6, pady=5)
        frame.grid_columnconfigure(0, weight=1)

        item.row_title = ctk.CTkLabel(frame, text=item.title, anchor="w",
                                      font=ctk.CTkFont(size=14, weight="bold"))
        item.row_title.grid(row=0, column=0, sticky="ew", padx=14, pady=(10, 2))

        item.action_btn = ctk.CTkButton(frame, width=120, height=28,
                                        fg_color="transparent", border_width=1)
        item.action_btn.grid(row=0, column=1, padx=10, pady=(10, 2))

        item.bar = ctk.CTkProgressBar(frame, progress_color=ACCENT)
        item.bar.set(0)
        item.bar.grid(row=1, column=0, columnspan=2, sticky="ew", padx=14)

        item.status_lbl = ctk.CTkLabel(frame, text="", anchor="w", text_color="gray60")
        item.status_lbl.grid(row=2, column=0, columnspan=2, sticky="ew", padx=14, pady=(4, 10))
        item.row = frame

    def _status_text(self, it):
        s = self.t(it.status)
        if it.status == "downloading":
            s += f" · {int(it.progress * 100)}%"
            if it.speed:
                s += f" · {fmt_speed(it.speed)}"
        return s

    def _poll(self):
        while True:
            try:
                url = self.inbox.get_nowait()
            except queue.Empty:
                break
            self._enqueue(url, False)
        for it in self.items:
            if it.row is None:
                continue
            it.row_title.configure(text=it.title[:90])
            it.bar.set(it.progress)
            it.status_lbl.configure(text=self._status_text(it))

            if it.status == "done":
                it.action_btn.configure(text=self.t("open"), state="normal",
                                        command=lambda f=it.folder: self._open_folder(f))
            elif it.status in FINISHED:
                it.action_btn.configure(text=self.t(it.status), state="disabled")
            else:
                it.action_btn.configure(text=self.t("cancel"), state="normal",
                                        command=lambda i=it: self._cancel(i))
        self.after(300, self._poll)

    def _clear_finished(self):
        keep = []
        for it in self.items:
            if it.status in FINISHED:
                if it.row is not None:
                    it.row.destroy()
            else:
                keep.append(it)
        self.items = keep


if __name__ == "__main__":
    DownX().mainloop()
